Hi, <?php echo e($demo->receiver); ?>


You have exceeded the deadline for project <?php echo e($demo->demo_one); ?> .

Project Name : <?php echo e($demo->demo_one); ?>

End Date : <?php echo e($demo->demo_two); ?>