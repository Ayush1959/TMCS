Hi, <?php echo e($name); ?>

Your Project <?php echo e($pname); ?> is about to reach its deadline.