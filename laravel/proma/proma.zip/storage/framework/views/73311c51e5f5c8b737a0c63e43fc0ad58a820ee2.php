Hi, <?php echo e($demo->receiver); ?>


Your Project <?php echo e($demo->demo_one); ?> is about to reach its deadline.

Project Name : <?php echo e($demo->demo_one); ?>

End Date : <?php echo e($demo->demo_two); ?>