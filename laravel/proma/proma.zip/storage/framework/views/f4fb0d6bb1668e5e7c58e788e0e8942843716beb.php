Hi, <?php echo e($name); ?>

You have exceeded the deadline for project <?php echo e($pname); ?> .

Project Name : <?php echo e($pname); ?>

End Date : <?php echo e($end); ?>