<?php $__env->startSection('content'); ?>
<div class="row">
    <router-view name="DataIndex"></router-view>
    <router-view></router-view>
    
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.apphome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>