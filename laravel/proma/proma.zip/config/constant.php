<?php
// use Illuminate\Support\Facades\Config;

return [
    'Success' => 200,
    'Object_Created' => 201,
    'Validation_Error' => 210,
    'DB_Save_Error' => 208
];