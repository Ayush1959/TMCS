<template>
  <div>
    <!-- <aside class="sidebar">
      <nav class="bgb">
        <ul class="list-group bgb mrgl">
          <li class="list-group-item bgb">
            <span class="glyphicon glyphicon-folder-open"></span>
            <router-link :to="{name: 'dataCreate'}" class="bttn">Project</router-link>
          </li>
          <li class="list-group-item bgb">
            <span class="glyphicon glyphicon-plus"></span>
            <router-link :to="{name: 'dataRead'}" class="bttn">Score</router-link>
          </li>
        </ul>
      </nav>
    </aside>-->
    <div class="container">
      <!-- <h1>Welcome</h1> -->
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style>
.sidebar {
  width: 11%;
  /* width: 150px; */
  background-color: #000000;
  left: 0;
  height: 200px;
}
.nav_title {
  /* text-align: center; */
  font-weight: 500;
}
.bgb {
  background-color: black;
}
.mrgl {
  margin-left: 16px;
}
</style>
