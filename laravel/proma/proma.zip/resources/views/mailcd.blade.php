Hi, {{ $name }}
You have exceeded the deadline for project {{ $pname }} .

Project Name : {{ $pname }}
End Date : {{ $end }}