Hi, {{ $demo->receiver }}

You have exceeded the deadline for project {{ $demo->demo_one }} .

Project Name : {{ $demo->demo_one }}
End Date : {{ $demo->demo_two }}