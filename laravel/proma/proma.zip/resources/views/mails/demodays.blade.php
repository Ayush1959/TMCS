Hi, {{ $demo->receiver }}

Your Project {{ $demo->demo_one }} is about to reach its deadline.

Project Name : {{ $demo->demo_one }}
End Date : {{ $demo->demo_two }}