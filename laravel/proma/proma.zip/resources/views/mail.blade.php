Hi, {{ $name }}
Your Project {{ $pname }} is about to reach its deadline.


Project Name : {{ $pname }}
End Date : {{ $end }}